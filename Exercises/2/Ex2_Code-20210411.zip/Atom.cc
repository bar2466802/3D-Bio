#include "Atom.h"
#include "PDB.h"
#include <string>
#include <string.h>
#include <math.h>
#include "macros.h"

const unsigned short Atom::resNameLen            =   3;
const unsigned short Atom::atomNameLen           =   4;
const float Atom::defaultOccupancy               =   1.0;
const float Atom::defaultTempFactor              =   0.0;

std::string Atom::parseAtomName(const char* const atomName_) {
  std::string atomname;
  switch (strlen(atomName_)) {
  case 1:
    atomname = " " + std::string(atomName_) + "  ";
    break;
  case 2:
    atomname = " " + std::string(atomName_) + " ";
    break;
  case 3:
    atomname = " " + std::string(atomName_ );
    break;
  default:
    atomname = std::string(atomName_).substr(0,4);
  }

  return atomname;
}


Atom::Atom()
  : Vector3(), atomEntryType(ATOM), chId(' '), altLoc(' '), atomId(0),
    residueId(0), residueSeqICode(' '), atomName("    "), resType(' '), resName("   "),
    occupancy(defaultOccupancy), tempFactor(defaultTempFactor),sseInfo(std::pair<char,short>(0,0))
{}

Atom::Atom(const Vector3& p, const char ch, const unsigned int aid,
	   const unsigned int resid,
	   const char* const atomName_, const char resTp, const char resICode) :
  Vector3(p), atomEntryType(ATOM), chId(ch), altLoc(' '), atomId(aid),
  residueId(resid), residueSeqICode(resICode), resType(resTp),
  occupancy(defaultOccupancy), tempFactor(defaultTempFactor),sseInfo(std::pair<char,short>(0,0))
{
  atomName = parseAtomName(atomName_);
  resName = std::string(PDB::residueLongName(resTp)).substr(0,3);
}

Atom::Atom(const Vector3& p, const AtomEntryType atp, const char ch,
    const unsigned int aid, const unsigned int resid,
    const char* const atomName_, const char resTp, const char* const res, const char resICode) :
    Vector3(p), atomEntryType(atp), chId(ch), altLoc(' '), atomId(aid),
    residueId(resid), residueSeqICode(resICode), resType(resTp), resName("   "),
    occupancy(defaultOccupancy), tempFactor(defaultTempFactor),sseInfo(std::pair<char,short>(0,0))
{
  atomName = parseAtomName(atomName_);
  resName = std::string(res).substr(0,3);
}

Atom::Atom(const Vector3& p, const AtomEntryType atp, const char ch,
	   const unsigned int aid, const unsigned int resid,
	   const char* const atomName_, const char resTp, const char* const res,
	   const float occup, const float tmp, const char resICode) :
  Vector3(p), atomEntryType(atp), chId(ch), altLoc(' '), atomId(aid),
  residueId(resid), residueSeqICode(resICode), resType(resTp), resName("   "),
  occupancy(occup), tempFactor(tmp), sseInfo(std::pair<char,short>(0,0))
{
  atomName = parseAtomName(atomName_);
  resName = std::string(res).substr(0,3);
}

Atom::Atom(const Vector3& p, unsigned int aid) :
  Vector3(p), atomEntryType(ATOM), chId(' '), altLoc(' '), atomId(aid), residueId(0),
  residueSeqICode(' '), atomName("    "), resType(' '), resName("   "),
  occupancy(defaultOccupancy), tempFactor(defaultTempFactor), sseInfo(std::pair<char,short>(0,0))
{}

Atom::Atom(const char* const PDBrec) :
  Vector3(PDB::atomXCoord(PDBrec),
	  PDB::atomYCoord(PDBrec),
	  PDB::atomZCoord(PDBrec)),
  atomEntryType(PDB::getAtomEntryType(PDBrec)),
  chId(PDB::atomChainId(PDBrec)),
  altLoc(PDB::atomAltLocIndicator(PDBrec)),
  atomId(PDB::atomIndex(PDBrec)),
  residueId(PDB::atomResidueIndex(PDBrec)),
  residueSeqICode(PDB::atomResidueICode(PDBrec)),
  resType(PDB::atomResidueType(PDBrec)),
  occupancy(PDB::getOccupancy(PDBrec)),
  tempFactor(PDB::getTempFactor(PDBrec)),
  sseInfo(std::pair<char,short>(0,0))
{
  //const char* const atomType = PDB::atomType(PDBrec);
  //atomName = string(atomType).substr(0,4);
  atomName = PDB::atomType(PDBrec);
  resName = PDB::getAtomResidueLongName(PDBrec);
  //resName = string(residueType).substr(0,3);
}

char Atom::chainId() const {
  return chId;
}

char Atom::altLocIndicator() const {
  return altLoc;
}

unsigned int Atom::atomIndex() const {
  return atomId;
}

int Atom::residueIndex() const {
  return residueId;
}

std::string Atom::residueSequenceID() const {
  static const size_t MAX_CHARS_LENGTH = 5;
  char cResId[MAX_CHARS_LENGTH];
  sprintf(cResId, "%d", residueId);
  std::string sResId(cResId);
  sResId += residueSeqICode;
  return sResId;
}

char Atom::residueICode() const {
  return residueSeqICode;
}

const char *const Atom::type() const {
  return atomName.c_str();
}

char Atom::residueType() const {
  return resType;
}

const char *const Atom::residueName() const
{
  return resName.c_str();
}

void Atom::setChainId(const char newChainId) {
  chId = newChainId;
}

void Atom::setAtomId(unsigned int newAtomId) {
  atomId = newAtomId;
}

AtomEntryType Atom::getAtomEntryType() const {
  return atomEntryType;
}

float Atom::getOccupancy() const {
  return occupancy;
}

float Atom::getTempFactor() const {
  return tempFactor;
}

void Atom::setTempFactor(float ftemp) {
  tempFactor=ftemp;
}

bool Atom::isBackbone() const
{
  const char* atomType = type();
  if (atomType[1] == 'N' && atomType[2] == ' ')
    return true;
  else if (atomType[1] == 'C' && atomType[2] == 'A' && atomType[3] == ' ')
    return true;
  else if (atomType[1] == 'C' && atomType[2] == ' ')
    return true;
  else if (atomType[1] == 'O' && atomType[2] == ' ')
    return true;
  else
    return false;
}

bool Atom::isCA() const
{
  const char* atomType = type();
  if (atomType[1] == 'C' && atomType[2] == 'A' && atomType[3] == ' ')
    return true;
  else
    return false;
}

bool Atom::isCB() const
{
  const char* atomType = type();
  if (atomType[1] == 'C' && atomType[2] == 'B' && atomType[3] == ' ')
    return true;
  else
    return false;
}

bool Atom::isN() const
{
  const char* atomType = type();
  if (atomType[1] == 'N' && atomType[2] == ' ')
    return true;
  else
    return false;
}

bool Atom::isC() const
{
  const char* atomType = type();
  if (atomType[1] == 'C' && atomType[2] == ' ')
    return true;
  else
    return false;
}

bool Atom::isO() const
{
  const char* atomType = type();
  if (atomType[1] == 'O' && atomType[2] == ' ')
    return true;
  else
    return false;
}

bool Atom::isCG() const
{
  const char* atomType = type();
  if (atomType[1] == 'C' && atomType[2] == 'G' && atomType[3] == ' ')
    return true;
  else
    return false;
}

bool Atom::isCD() const
{
  const char* atomType = type();
  if (atomType[1] == 'C' && atomType[2] == 'D' && atomType[3] == ' ')
    return true;
  else
    return false;
}

bool Atom::isCE() const
{
  const char* atomType = type();
  if (atomType[1] == 'C' && atomType[2] == 'E' && atomType[3] == ' ')
    return true;
  else
    return false;
}

bool Atom::isCD1() const
{
  const char* atomType = type();
  if (atomType[1] == 'C' && atomType[2] == 'D' && atomType[3] == '1')
    return true;
  else
    return false;
}

bool Atom::isCD2() const
{
  const char* atomType = type();
  if (atomType[1] == 'C' && atomType[2] == 'D' && atomType[3] == '2')
    return true;
  else
    return false;
}

bool Atom::isCG1() const
{
  const char* atomType = type();
  if (atomType[1] == 'C' && atomType[2] == 'G' && atomType[3] == '1')
    return true;
  else
    return false;
}

bool Atom::isCG2() const
{
  const char* atomType = type();
  if (atomType[1] == 'C' && atomType[2] == 'G' && atomType[3] == '2')
    return true;
  else
    return false;
}

bool Atom::isCE1() const
{
  const char* atomType = type();
  if (atomType[1] == 'C' && atomType[2] == 'E' && atomType[3] == '1')
    return true;
  else
    return false;
}

bool Atom::isCE2() const
{
  const char* atomType = type();
  if (atomType[1] == 'C' && atomType[2] == 'E' && atomType[3] == '2')
    return true;
  else
    return false;
}

bool Atom::isCE3() const
{
  const char* atomType = type();
  if (atomType[1] == 'C' && atomType[2] == 'E' && atomType[3] == '3')
    return true;
  else
    return false;
}

bool Atom::isCZ() const
{
  const char* atomType = type();
  if (atomType[1] == 'C' && atomType[2] == 'Z' && atomType[3] == ' ')
    return true;
  else
    return false;
}

bool Atom::isCZ2() const
{
  const char* atomType = type();
  if (atomType[1] == 'C' && atomType[2] == 'Z' && atomType[3] == '2')
    return true;
  else
    return false;
}

bool Atom::isCZ3() const
{
  const char* atomType = type();
  if (atomType[1] == 'C' && atomType[2] == 'Z' && atomType[3] == '3')
    return true;
  else
    return false;
}

bool Atom::isCH2() const
{
  const char* atomType = type();
  if (atomType[1] == 'C' && atomType[2] == 'H' && atomType[3] == '2')
    return true;
  else
    return false;
}

bool Atom::isOD1() const
{
  const char* atomType = type();
  if (atomType[1] == 'O' && atomType[2] == 'D' && atomType[3] == '1')
    return true;
  else
    return false;
}

bool Atom::isOD2() const
{
  const char* atomType = type();
  if (atomType[1] == 'O' && atomType[2] == 'D' && atomType[3] == '2')
    return true;
  else
    return false;
}

bool Atom::isOE1() const
{
  const char* atomType = type();
  if (atomType[1] == 'O' && atomType[2] == 'E' && atomType[3] == '1')
    return true;
  else
    return false;
}

bool Atom::isOE2() const
{
  const char* atomType = type();
  if (atomType[1] == 'O' && atomType[2] == 'E' && atomType[3] == '2')
    return true;
  else
    return false;
}

bool Atom::isOH() const
{
  const char* atomType = type();
  if (atomType[1] == 'O' && atomType[2] == 'H' && atomType[3] == ' ')
    return true;
  else
    return false;
}

bool Atom::isOG() const
{
  const char* atomType = type();
  if (atomType[1] == 'O' && atomType[2] == 'G' && atomType[3] == ' ')
    return true;
  else
    return false;
}

bool Atom::isOG1() const
{
  const char* atomType = type();
  if (atomType[1] == 'O' && atomType[2] == 'G' && atomType[3] == '1')
    return true;
  else
    return false;
}

bool Atom::isNE() const
{
  const char* atomType = type();
  if (atomType[1] == 'N' && atomType[2] == 'E' && atomType[3] == ' ')
    return true;
  else
    return false;
}

bool Atom::isND1() const
{
  const char* atomType = type();
  if (atomType[1] == 'N' && atomType[2] == 'D' && atomType[3] == '1')
    return true;
  else
    return false;
}

bool Atom::isND2() const
{
  const char* atomType = type();
  if (atomType[1] == 'N' && atomType[2] == 'D' && atomType[3] == '2')
    return true;
  else
    return false;
}

bool Atom::isNE1() const
{
  const char* atomType = type();
  if (atomType[1] == 'N' && atomType[2] == 'E' && atomType[3] == '1')
    return true;
  else
    return false;
}

bool Atom::isNE2() const
{
  const char* atomType = type();
  if (atomType[1] == 'N' && atomType[2] == 'E' && atomType[3] == '2')
    return true;
  else
    return false;
}

bool Atom::isNH1() const
{
  const char* atomType = type();
  if (atomType[1] == 'N' && atomType[2] == 'H' && atomType[3] == '1')
    return true;
  else
    return false;
}

bool Atom::isNH2() const
{
  const char* atomType = type();
  if (atomType[1] == 'N' && atomType[2] == 'H' && atomType[3] == '2')
    return true;
  else
    return false;
}

bool Atom::isNZ() const
{
  const char* atomType = type();
  if (atomType[1] == 'N' && atomType[2] == 'Z' && atomType[3] == ' ')
    return true;
  else
    return false;
}

bool Atom::isSD() const
{
  const char* atomType = type();
  if (atomType[1] == 'S' && atomType[2] == 'D' && atomType[3] == ' ')
    return true;
  else
    return false;
}

bool Atom::isSG() const
{
  const char* atomType = type();
  if (atomType[1] == 'S' && atomType[2] == 'G' && atomType[3] == ' ')
    return true;
  else
    return false;
}

bool Atom::isH() const
{
  const char* atomType = type();
  if (atomType[1] == 'H' || atomType[1] == 'D' || atomType[0] == 'H' || atomType[0] == 'D')
    return true;
  else
    return false;
}

bool Atom::isWater() const
{
  const char* resName = residueName();
  if (strncmp(resName, "HOH", 3) || strncmp(resName,"DOD", 3))
    return true;
  else
    return false;
}

/* RNA backbone
//        OP1    H5' H4'  O4'   residue
//         |      |    \ /   \  /
//        -P-O5'-C5'---C4'    C1'
//         |      |     \     / \
//        OP2    H5''   C3'--C2' H1'
//                     / \   / \
//                  O3' H3' O2' H2''
//                   |       |
//                          H2'
*/
bool Atom::isRNABackbone() const {
  const char* atomType = type();
  return ((atomType[1] == 'O' && atomType[2] == 'P') || isSugarAtom() || isP());
}

bool Atom::isP() const {
  const char* atomType = type();
  if (atomType[1] == 'P' && atomType[2] == ' ') {
    return true;
  }
  return false;
}

bool Atom::isSugarAtom() const {
  const char* atomType = type();
  // '*' for old convention
  if (atomType[3] == '*' || atomType[3] == '\''  ) {
    return true;
  }
  return false;
}

std::ostream& operator<<(std::ostream& s, const Atom& at)
{
  // first 6 chars (1-6) stand for field type
  s.setf(std::ios::left, std::ios::adjustfield);
  s.width(6);
  if (at.atomEntryType == ATOM)
    s << "ATOM";
  else if (at.atomEntryType == HETATM)
    s << "HETATM";
  else
    s << "UNK";

  // next 5 chars (7-11) stand for atom id
  s.setf(std::ios::right, std::ios::adjustfield);
  s.width(5);
  s << at.atomId;

  // skip an undefined position (12)
  s.width(1);
  s << " ";

  // 4 positions (13-16) for atom name
  //s.width(4); worked well with gcc-2.95
  s << at.atomName;

  // skip the alternate indication position (17)
  s.width(1);
  s << at.altLoc;

  // 3 positions for residue name (18-20)
  //s.width(3); worked well with gcc-2.95
  if(at.resName.length()==3) {
    s << at.resName;
  } else {
    s << "   ";
  }

  // 1 position for chain identifier (22) + 1 skipped (21)
  s.width(1);
  s << " " << at.chId; // skip the chain identifier
  s.width(4);

  // 4 position for residue number (23-26)
  s << at.residueIndex(); // residue sequence number
  s.width(1);
  s << at.residueICode(); // residue insertion code (27)
  s.setf(std::ios::fixed, std::ios::floatfield);
  s << "   "; // skip 3 undefined positions (28-30)

  // coordinates (31-38,39-46,47-54)
  s.width(8);
  s.precision(3);
  s << at[0];
  s.width(8);
  s.precision(3);
  s << at[1];
  s.width(8);
  s.precision(3);
  s << at[2];
  // occupancy (55-60)
  s.width(6);
  s.precision(2);
  s << at.occupancy;
  // temp. factor (61-66)
  s.width(6);
  s.precision(2);
  s << at.tempFactor;

  //  s << endl;
  return s;
}
